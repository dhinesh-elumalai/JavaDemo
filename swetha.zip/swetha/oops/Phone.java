package swetha.oops;

public abstract class Phone {

	int id;
	String name;
	
	public abstract void displayMyName();
	
	public void displayName() {
		System.out.println("My Name");
	}
}
