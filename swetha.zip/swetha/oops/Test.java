package swetha.oops;

public class Test {

	public static void main(String[] args) {
		//Inheritance:
		Mobile mobile = new Mobile();
		Vivo vivoEmptyConstructor = new Vivo();
		vivoEmptyConstructor.setModel("Vivo V20");
		Vivo vivoAllConstructor = new Vivo("Blue", "Mobile", 12000, 1, "Vivo V19", "50MP", "Dhinesh");
		vivoAllConstructor.displayFingerPrint();
		System.out.println("vivoEmptyConstructor " + vivoEmptyConstructor);
		System.out.println("vivoAllConstructor "+ vivoAllConstructor);
		//Polymorphism:
		vivoAllConstructor.displayHello(); // Runtime Polymorphism -- overriding
		vivoAllConstructor.displayHello("Swetha"); // CompileTime Polymorphism -- overloading
		
		//Abstraction:
		Iphone iphone = new Iphone();
		
		// Encapsulation:
		//vivoEmptyConstructor.
		//mobile.brand = null;
	}

}
