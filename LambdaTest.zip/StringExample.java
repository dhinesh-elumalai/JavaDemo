package swetha.oops;

public class StringExample {

	public static void main(String[] args) {
		//Initializing String
		String firstname = "Dhinesh";
		String firstName2 = "Dhinesh";
		String name2 = new String("Dhinesh");
		char[] nameArray = {'D', 'h', 'i', 'n','e', 's', 'h'};
		String name3 = new String(nameArray);
		byte[] numArray = {66, 67, 89};
		String name4 = new String(numArray);
		System.out.println(firstname.hashCode() +""+ name2.hashCode() +"" + name3.hashCode());
		String secondName= "Babu";
		System.out.println(firstname.hashCode());
		String fullName = firstname + secondName;
		
		boolean check = firstname == firstName2;
		boolean checkE = firstname == name2;
		boolean checkEquals = firstname.equals(name2);
		System.out.println(check +" "+ checkEquals + " "+ checkE);
		
		StringBuffer nameStBuffer = new StringBuffer("Dhinesh");
		StringBuffer nameStBuffer2 = new StringBuffer("Dhinesh");
		nameStBuffer = new StringBuffer("Rajesh");
		System.out.println(nameStBuffer.hashCode() +" " + nameStBuffer2.hashCode());
	}
}
