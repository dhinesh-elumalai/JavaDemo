package swetha.oops;

public interface PhoneInterface {

	public void displayName();
}
