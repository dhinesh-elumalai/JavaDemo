package swetha.oops;


public class ArrayExample {

	public static void main(String[] args) {
		int n=0;
		int[] numArray = new int[n];
		char[] charArray = new char[n];
		String[] stringArray = {"Dhinesh", "Babu", "Swetha"};
		//numArray[0]=1;
		for(int i=0;i<stringArray.length;i++) {
			System.out.println(stringArray[i]);
		}
		
		// Enhanced For loop
		
		for(String name : stringArray) {
			System.out.println(name);
		}
	}

}
