package swetha.oops;

public class Mobile {

	String color;
	String brand;
	int price;
	int ramSize;
	
	public void displayHello() {
		System.out.println("Hello User!!");
	}

	public Mobile(String color, String brand, int price, int ramSize) {
		super();
		this.color = color;
		this.brand = brand;
		this.price = price;
		this.ramSize = ramSize;
	}

	public Mobile() {
		super();
	}
	
}
