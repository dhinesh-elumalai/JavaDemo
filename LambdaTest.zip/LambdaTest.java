package swetha.oops;

import java.util.function.BiConsumer;
import java.util.function.Consumer;

public class LambdaTest {

	public static void main(String[] args) {
	    Light light3 = new Light() {

			@Override
			public void getBrightness(int num) {
				System.out.println("Lambda has been called.");
			}
	    	
	    };
	    
		Light light =  num -> {
			System.out.println("Lambda has been called.");
		};
		
		Light light2 = num -> {
			System.out.println("Lambda2 has been called.");
		};
		Runnable runnable = ()->{
				System.out.println("Hi I am run method");
		};
		Consumer<Integer> consumer = num ->{
			System.out.println(num);
		};
		
		light.getBrightness(5);
		light2.getBrightness(4);
		runnable.run();
		consumer.accept(4);
	}

}
