package swetha.oops;

public interface MobileInterface {

}
