package swetha.oops;
public class Vivo extends Mobile{

	private String model;
	private String camera;
	private String owner;
	
	public void displayFingerPrint() {
		System.out.println("Finger print accessed!!"+ super.color);
		super.displayHello();
	}
	
	@Override
	public void displayHello() {
		System.out.println("Hello "+ owner);
	}

	public void displayHello(String ownerName) {
		System.out.println("Hello "+ ownerName);
	}
	
	public Vivo() {
		super(); 
	}

	public Vivo(String color, String brand, int price, int ramSize, String model, String camera, String owner) {
		super(color, brand, price, ramSize);
		this.model = model;
		this.camera = camera;
		this.owner = owner;
	}

	@Override
	public String toString() {
		return "Vivo [model=" + model + ", camera=" + camera + ", owner=" + owner + ", color=" + color + ", brand="
				+ brand + ", price=" + price + ", ramSize=" + ramSize + "]";
	}

	public String getModel() {
		return model+" This is mY model";
	}

	public void setModel(String model) {
		if(model==null) {
			
		}
		this.model = model;
	}

	public String getCamera() {
		return camera;
	}

	public void setCamera(String camera) {
		this.camera = camera;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}
	
	
}
