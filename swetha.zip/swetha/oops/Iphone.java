package swetha.oops;

public class Iphone extends Phone implements PhoneInterface, MobileInterface{

	@Override
	public void displayMyName() {
		System.out.println("This is Iphone");
	}

}
