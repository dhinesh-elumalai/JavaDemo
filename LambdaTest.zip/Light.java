package swetha.oops;

@FunctionalInterface
public interface Light {
	public void getBrightness(int num);
}
